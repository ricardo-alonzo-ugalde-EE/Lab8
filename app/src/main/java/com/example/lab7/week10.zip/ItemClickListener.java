package com.example.lab7;

import com.google.android.gms.maps.model.LatLng;

public interface ItemClickListener {
    void onItmeClick(LatLng latLng);
}
